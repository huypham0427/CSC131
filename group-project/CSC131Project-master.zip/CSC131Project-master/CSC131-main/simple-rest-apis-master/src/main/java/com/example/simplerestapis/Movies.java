package com.example.simplerestapis;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

//import com.google.gson.annotations.SerializedName;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class Movies {
    /*
    @SerializedName("Categories")
    private ArrayList<Categories> CategoryList;
    @SuppressWarnings("unchecked")
    public static void main( String[] args )
    {

        //First Employee
        JSONObject employeeDetails = new JSONObject();
        employeeDetails.put("firstName", "Lokesh");
        employeeDetails.put("lastName", "Gupta");
        employeeDetails.put("website", "howtodoinjava.com");


    }

     */
}
